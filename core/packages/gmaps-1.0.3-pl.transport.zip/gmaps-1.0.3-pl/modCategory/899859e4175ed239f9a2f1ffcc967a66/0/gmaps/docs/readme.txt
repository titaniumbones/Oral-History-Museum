--------------------
Snippets: Gmaps
--------------------
Author: Coroico <coroico@wangba.fr>

Display a Google Map with markers and graphical layers - API Google Maps V3.

Documentation : core/components/gmaps/docs
Demo web site : www.revo.wangba.fr