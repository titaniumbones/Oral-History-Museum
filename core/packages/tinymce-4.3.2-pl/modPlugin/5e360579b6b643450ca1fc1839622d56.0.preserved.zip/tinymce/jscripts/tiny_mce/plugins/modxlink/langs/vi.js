tinyMCE.addI18n('vi.modxlink',{
    link_desc:"Insert/edit link"
});